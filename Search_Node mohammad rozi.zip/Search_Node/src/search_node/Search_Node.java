
package search_node;

public class Search_Node {
    node head;

    private boolean searchNodeRecursiveWays(node next, int value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    static class node {
        int data;
        node next;
        
        node (int a) {
            data = a;
            next = null;
            
        }
    }
    private void priviousItems(Search_Node list) {
        list.head = new node(10);
        node secondnode = new node(16);
        node thirdnode = new node (21);
        node fourthnode = new node (27);
        
        list.head.next = secondnode;
        list.head.next.next = thirdnode;
        list.head.next.next.next = fourthnode;
    }
    
    private void printLinkedList(String message) {
        System.out.println(message);
        node listnode = head;
        while (listnode != null) {
            System.out.println(listnode.data + "");
            listnode = listnode.next;
        }
        System.out.println("");
    }
    public static void main(String[] args) {
        Search_Node list = new Search_Node();
        list.priviousItems(list);
        list.printLinkedList("inisialisasi");
        boolean found = list.searchNodeInteractiveWays(21);
        //boolean found = list.searchNodeInteractiveWays(list.head, 48);
        if (found) {
            System.out.println("node ada dalam daftar yang diberikan");
        }else{
            System.out.println("node tidak ada dalam daftar yang diberikan");
        }
    }
    private boolean searchNodeInteractiveWays(int value) {
        node temp = head;
        while (temp != null) {
            if (temp.data == value) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }
    private boolean searchNodeRecursiveways(node temp,int value) {
        if (temp == null) {
            return false;
        }
        if (temp.data == value) {
            return true;
        }
        return searchNodeRecursiveWays(temp.next, value);
    }
    

   
    
}
