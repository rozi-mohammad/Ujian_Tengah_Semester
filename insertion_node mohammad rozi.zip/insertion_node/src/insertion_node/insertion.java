
package insertion_node;


public class insertion {
    
    public static void main(String[] args){
        Insertion_node front = new Insertion_node(25,null);
        System.out.println(front);
        
        StringNode strfront = new StringNode("mohammad rozi",null);
        System.out.println(strfront);
    }
    
}
