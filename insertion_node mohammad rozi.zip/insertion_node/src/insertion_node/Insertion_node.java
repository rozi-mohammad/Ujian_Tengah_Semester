
package insertion_node;


public class Insertion_node {

   public int data;
   public Insertion_node next;
   
   public Insertion_node(int data, Insertion_node next){
       this.data = data;
       this.next = next;
   }
   
   public String toString() {
       return data + "";
   }
   
    
    
}
