
package deletion_node;


public class Deletion_node {
    node head;

    private void printLinkedlist(String after_deleting_node) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    /*linked list node*/
    static class node {
        int data;
        node next;
        
        node(int a){
            data = a;
            next = null;
            
        }
    }
    private void priviousItems(Deletion_node list){
        list.head = new node(12);
        node secondNode = new node(34);
        node thirdNode = new node (56);
        node fourthNode = new node (78);
        
        list.head.next = secondNode;
        list.head.next.next = thirdNode;
        list.head.next.next.next =fourthNode;
    }
    
    private void printLinkedList(String message) {
        System.out.println(message);
        node listnode = head;
        while (listnode != null) {
            System.out.println(listnode.data +"");
            listnode = listnode.next;
        }
        System.out.println("");
    }
    public static void main(String[] args) {
        Deletion_node list= new Deletion_node();
        list.priviousItems(list);
        list.printLinkedList("Inisialisasi");
        list.Deletion_node(10);
    }
    //delete node
    private void Deletion_node(int key){
        node temp = head;
        node prev = null;
        if (temp !=null && temp.data == key) {
            head = temp.next;
            printLinkedList("node deleted from head");
            return;
        }
        while (temp != null && temp.data !=key) {
            prev = temp;
            temp = temp.next;
        }
        if (temp == null) {
            System.out.println("node does not exixt");
            return;
        }
        
        prev.next = temp.next;
        printLinkedlist("after deleting node");
    }
}
